// import java.util.*;
// class JobSeq {
//     public static void main(String[] args) {
//         char jobs[] = {'A','B','C','D'};
//         int deadline[] = {2,1,2,1};
//         int profit[] = {100,19,27,25};
//         int n = jobs.length;
//         boolean slot[] = new boolean[n];
//         char result[] = new char[n];
//         int total = 0;

//         Integer order[] = {0,1,2,3};
//         Arrays.sort(order, (a,b) -> profit[b]-profit[a]);

//         for (int i : order)
//             for (int j = Math.min(n, deadline[i])-1; j >= 0; j--)
//                 if (!slot[j]) { slot[j]=true; result[j]=jobs[i]; total+=profit[i]; break; }

//         System.out.println("Job Order: " + Arrays.toString(result));
//         System.out.println("Total Profit: " + total);
//     }
// }


import java.util.*;

public class JobSequencing {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Taking number of jobs from user
        System.out.print("Enter number of jobs: ");
        int n = sc.nextInt();

        char[] jobs = new char[n];
        int[] deadline = new int[n];
        int[] profit = new int[n];

        // Taking job details from user
        for (int i = 0; i < n; i++) {
            System.out.print("Enter job name (single character): ");
            jobs[i] = sc.next().charAt(0);

            System.out.print("Enter deadline for job " + jobs[i] + ": ");
            deadline[i] = sc.nextInt();

            System.out.print("Enter profit for job " + jobs[i] + ": ");
            profit[i] = sc.nextInt();
        }

        boolean[] slot = new boolean[n];
        char[] result = new char[n];
        int total = 0;

        // Create an array of indexes to sort by profit
        Integer[] order = new Integer[n];
        for (int i = 0; i < n; i++)
            order[i] = i;

        // Sort jobs in descending order of profit
        Arrays.sort(order, (a, b) -> profit[b] - profit[a]);

        // Job sequencing logic
        for (int i : order) {
            for (int j = Math.min(n, deadline[i]) - 1; j >= 0; j--) {
                if (!slot[j]) {
                    slot[j] = true;
                    result[j] = jobs[i];
                    total += profit[i];
                    break;
                }
            }
        }

        // Output result
        System.out.println("\nJob Order: " + Arrays.toString(result));
        System.out.println("Total Profit: " + total);

        sc.close();
    }
}

// TIME COMPLEXITY: O(n²)
