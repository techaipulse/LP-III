public class Queens{
    final int N = 8;
    boolean solve(int board[][], int col) {
        if (col >= N) return true;
        for (int i = 0; i < N; i++) {
            if (isSafe(board, i, col)) {
                board[i][col] = 1;
                if (solve(board, col + 1)) return true;
                board[i][col] = 0;
            }
        }
        return false;
    }
    boolean isSafe(int b[][], int r, int c) {
        for (int i=0;i<c;i++) if (b[r][i]==1) return false;
        for (int i=r,j=c;i>=0&&j>=0;i--,j--) if (b[i][j]==1) return false;
        for (int i=r,j=c;i< N&&j>=0;i++,j--) if (b[i][j]==1) return false;
        return true;
    }
    public static void main(String[] args) {
        int board[][] = new int[8][8];
        new NQueens().solve(board, 0);
        for (int[] r : board)
            System.out.println(java.util.Arrays.toString(r));
    }
}

// TIME COMPLEXITY: O(N!)
