import java.util.*;

public class FractionalKnapsack{
    public static void main(String[] args) {
        int [] weight = {10, 20, 30};
        int [] val = {60, 100, 120};
        int cap = 50;
        double total = 0;
        double [][] ratio = new double[3][2];

        for(int i = 0; i < 3; i++){
            ratio[i][0] = (double) val[i]/weight[i];
        }

        Arrays.sort(ratio, (a,b) -> Double.compare(b[0],a[0]));

        for(int i = 0; i < 3 && cap > 0; i++){
            if (cap >= weight[i]){
                total += val[i];
                cap -= weight[i];
            }else{
                total += ratio[i][0]*cap;
                break;
            }
        }
        System.out.println("Total Profit: " + total);

    }
}