class BinomialCoefficient_DP {
    public static void main(String[] args) {
        int n=5,k=2;
        int C[][]=new int[n+1][k+1];
        for(int i=0;i<=n;i++)
            for(int j=0;j<=Math.min(i,k);j++)
                C[i][j]=(j==0||j==i)?1:C[i-1][j-1]+C[i-1][j];
        System.out.println("C("+n+","+k+") = "+C[n][k]);
    }
}

// TIME COMPLEXITY: O(nk)