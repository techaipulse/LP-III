public class NaiveandRabin_Karp {
    static void naive(String txt, String pat){
        for(int i=0;i<=txt.length()-pat.length();i++)
            if(txt.substring(i,i+pat.length()).equals(pat))
                System.out.println("Pattern found at index "+i);
    }
    static void rabinKarp(String txt, String pat, int q){
        int m=pat.length(), n=txt.length();
        int d=256, h=1, p=0, t=0;
        for(int i=0;i<m-1;i++) h=(h*d)%q;
        for(int i=0;i<m;i++){
            p=(d*p+pat.charAt(i))%q;
            t=(d*t+txt.charAt(i))%q;
        }
        for(int i=0;i<=n-m;i++){
            if(p==t && txt.substring(i,i+m).equals(pat))
                System.out.println("Pattern found at index "+i);
            if(i<n-m)
                t=(d*(t-txt.charAt(i)*h)+txt.charAt(i+m))%q;
            if(t<0)t+=q;
        }
    }
    public static void main(String[] a){
        String txt="ABCCDDAEFG", pat="CDD";
        System.out.println("Naive:");
        naive(txt,pat);
        System.out.println("Rabin-Karp:");
        rabinKarp(txt,pat,101);
    }
}

// TIME COMPLEXITY:
// Naive: O((n–m+1)·m)
// Rabin–Karp: O(n + m) (average case)
