class Knapsack01 {
    public static void main(String[] args) {
        int val[] = { 60, 100, 125 };
        int wt[] = { 10, 20, 30 };
        int W = 50, n = val.length;
        int dp[][] = new int[n + 1][W + 1];

        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= W; j++)
                if (wt[i - 1] <= j) {
                    dp[i][j] = Math.max(val[i-1] + dp[i-1][j-wt[i-1]], dp[i-1][j]);
                } else {
                    dp[i][j] = dp[i - 1][j]; // item too heavy, skip it
                }

        System.out.println("Maximum value: " + dp[n][W]);
    }
}

// TIME COMPLEXITY: O(nj)