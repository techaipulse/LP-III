import java.util.*;

public class job {
    public static void main(String[] args) {
        char jobs [] = {'A','B','C','D'};
        int deadline[] = {2,1,2,1};
        int profit [] = {100,19,27,25};
        int n = jobs.length;
        Integer order[] = {0,1,2,3};
        boolean [] slot = new boolean[n];
        char [] result = new char[n];
        int total = 0;

        Arrays.sort(order,(a,b) -> profit[b]-profit[a]);
        for(int i: order){
            for(int j= Math.min(n,deadline[i])-1; j >=0 ; j--){
                if(!slot[j]){
                    slot[j] = true;
                    result[j] = jobs[i];
                    total += profit[i];
                    break;
                }
            }
        }

        System.out.println("Job order:"+ Arrays.toString(result));
        System.out.println("Total profit: " + total);

    }
    
}
